import UIKit
//state1 和 state2的答案在README.md里面
let key = [[2,3,1,1], [1,2,3,1], [1,1,2,3], [3,1,1,2]]
let state = [[0xAF,0xF9,0xB8,0x5B], [0x28, 0xBB, 0xE0, 0x7F],[0x54, 0x29, 0x97, 0x7F], [0x3E, 0x04, 0x92, 0x21]]
//let state1 = [[0xD1, 0x85, 0x1A, 0xF9], [0x93, 0x1B, 0xF7, 0x10], [0xCA, 0xA8, 0xB6, 0x45], [0x40, 0x8F, 0xF5, 0x20]]
//let state2 = [[0x87, 0xF2, 0x4D, 0x97], [0x6E, 0x4C, 0x90, 0xEC], [0x46, 0xE7, 0x4A, 0xC3], [0xA6, 0x8C, 0xD8, 0x95]]

func trueValue(_ num: Int) -> Int {
    return num >= 0b10000000 ? 0b00011011 : 0
}
if key.count != state[0].count {
    print("数据格式有误")
}else {
    var value = 0
    var isFirstNum:Bool
    for m in key {//用key的每一行
        for i in 0..<state.count {
            isFirstNum = true
           for j in 0..<state[i].count {//遍历state的每一列和自己的每一列
//            print(String(format:"此时参与运算的元素是m[j] = %d, state[j][i] = %0X",m[j], state[j][i]))
            let temp = trueValue(state[j][i])
            let leftValue = UInt8(truncating:NSNumber(value: (state[j][i]<<1)))
               switch m[j] {//根据行元素的不同
               case 1:
                if isFirstNum {
                    value = state[j][i]
                    isFirstNum = false
                }else{
                    value = value ^ state[j][i]
                }
               case 2:
                if isFirstNum {
                    value = Int(leftValue) ^ temp
                    isFirstNum = false
               }else{
                    value = value ^ (Int(leftValue) ^ temp)
               }
//                print("此时temp =", temp)
//                print(String(format: "移位前的数字 = %0X",state[j][i]))
//                print(String(format: "移位后的数字 = %0X",UInt8(truncating:NSNumber(value: (state[j][i]<<1)))))
//                print("此时移位后的数字 =", (state[j][i]<<1))
//                print(String(format: "case2的结果是%0X", value))
               case 3:
                if isFirstNum {
                    value = (Int(leftValue) ^ temp) ^ state[j][i]
                    isFirstNum = false
               }else{
                    value = value ^ ((Int(leftValue) ^ temp) ^ state[j][i])
                }
//                print(String(format: "case3的结果是%0X", value))
               default:
                   break
               }
           }
            
            print(String(format: "value = %02X", value))
    }
}

}

